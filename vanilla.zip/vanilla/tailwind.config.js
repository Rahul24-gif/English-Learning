/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./*.html",
    "./html/**/*.html",
    "./js/**/*.js",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
