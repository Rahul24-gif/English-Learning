// Basic routing logic
document.addEventListener('DOMContentLoaded', () => {
    const appContent = document.getElementById('app-content');

    const loadPage = (pageName) => {
        fetch(`html/${pageName}.html`)
            .then(response => response.text())
            .then(html => {
                appContent.innerHTML = html;
                // Execute scripts if any
                const scripts = appContent.querySelectorAll('script');
                scripts.forEach(script => {
                    const newScript = document.createElement('script');
                    if (script.src) {
                        newScript.src = script.src;
                    } else {
                        newScript.textContent = script.textContent;
                    }
                    document.body.appendChild(newScript);
                });
            })
            .catch(err => {
                console.error(`Failed to load page ${pageName}:`, err);
                appContent.innerHTML = `<p class="text-red-500">Error loading page: ${pageName}</p>`;
            });
    };

    const handleHashChange = () => {
        const hash = window.location.hash.substring(1);
        if (hash) {
            loadPage(hash);
        } else {
            // Default to login or dashboard if user is logged in
            const user = localStorage.getItem('user');
            if (user) {
                loadPage('dashboard');
            } else {
                loadPage('login');
            }
        }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Load initial page

    // Handle navigation clicks
    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = e.target.getAttribute('href').substring(1);
            window.location.hash = page;
        });
    });
});
